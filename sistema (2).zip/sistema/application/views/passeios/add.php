
<?php $this->load->view('layout/sidebar'); ?>


<!-- Main Content -->
<div id="content">

    <?php $this->load->view('layout/navbar'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('passeios'); ?>">Passeios</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
            </ol>
        </nav>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">


            <div class="card-body">

                <form class="passeio" method="POST" name="form_add">

                    <fieldset class="mt-4 border p-2 mb-4">

                        <legend class="font-small"><i class="fas fa-laptop"></i>&nbsp;Dados do Passeio</legend>

                        <div class="form-group row mb-3">

                            <div class="col-md-6 mb-3">
                                <label>Nome do Passeio</label>
                                <input type="text" class="form-control " name="passeio_nome" placeholder="Nome do passeio" value="<?php echo set_value('passeio_nome'); ?>">
                                <?php echo form_error('passeio_nome', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>
                            
                            <div class="col-md-3">
                                <label>Preço</label>
                                <input type="text" class="form-control  money" name="passeio_preco" placeholder="Preço do passeio" value="<?php echo set_value('passeio_preco'); ?>">
                                <?php echo form_error('servico_preco', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                            <div class="col-md-3">
                                <label>Passeio ativo</label>
                                <select class="custom-select" name="passeio_status">
                                    <option value="0">Não</option>
                                    <option value="1">Sim</option>
                                </select>
                            </div>

                        </div>

                        <div class="form-group row mb-3">

                            <div class="col-md-12">
                                <label>Descrição do passeio</label>
                                <textarea class="form-control " name="passeio_descricao" style="min-height: 100px!important"><?php echo set_value('passeio_descricao'); ?></textarea>
                                <?php echo form_error('passeio_descricao', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>

                        </div>

                    </fieldset>                    
                    <a title="Voltar" href="<?php echo base_url($this->router->fetch_class()); ?>" class="btn btn-secondary btn-sm ml-2">Voltar</a>
                    <button type="submit" class="btn btn-success btn-sm">Salvar</button>
                </form>

            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
