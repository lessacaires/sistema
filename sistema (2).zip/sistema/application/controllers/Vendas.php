<?php
defined('BASEPATH') OR exit('Acesso não e permitido');

class Vendas extends CI_Controller {
	public function __construct() {

		parent::__construct();

		if (!$this->ion_auth->logged_in())
		{
			$this->session->set_flashdata('info','Sua sessão expirou!');
			redirect('login');
		}
		$this->load->model('vendas_model');
	}
	
    public function index(){
		$data =  array(

			'titulo' => 'Vendas Cadastradas',

			'styles' => array(
				
				'vendor/datatables/dataTables.bootstrap4.min.css',

			),

			'scripts' => array(
				
				'vendor/datatables/jquery.dataTables.min.js',
				'vendor/datatables/app.js',
				'js/app.js',
				'js/jquery.mask.min.js',
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'js/demo/datatables-demo.js'
			),
			    'vendas' => $this->vendas_model->get_all(),
		);
             //erro na validação 
			// echo'<pre>';
			// print_r($data['vendas']);
			// exit();


			$this->load->view('layout/header', $data);
			$this->load->view('vendas/index');
			$this->load->view('layout/footer');

    }

    public function edd($vendas_id = NULL){
        if(!$vendas_id || $this->vendas_model->get_all()){
            $this->session->set_flashdata('error', 'Venda não encontrada');
        }else{

        }

        $this->load->view('layout/header', $data);
        $this->load->view('vendas/index');
        $this->load->view('layout/footer');
    }
}