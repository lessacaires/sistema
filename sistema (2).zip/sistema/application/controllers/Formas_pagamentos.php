<?php
    defined('BASEPATH') OR exit('Ação não permitida');

    class Formas_pagamentos extends CI_Controller{
        public function __Construct(){
            parent::__Construct();

            if(!$this->ion_auth->logged_in()){
                $this->session->set_flasdata('info', 'Sua sessão expirou');
                redirect('login');
            }
        }

        public function index(){

            $data = array(
                'titulo' => 'Formas de pagamento cadastradas',
                'styles' => array(
                    'vendor/datatables/dataTables.bootstrap4.min.css',
                ),
                'scripts' => array(
				
                    'vendor/datatables/jquery.dataTables.min.js',
                    'vendor/datatables/app.js',
                    'js/app.js',
                    'js/jquery.mask.min.js',
                    'vendor/datatables/dataTables.bootstrap4.min.js',
                    'js/demo/datatables-demo.js'
                ),
                'formas_pagamentos' => $this->core_model->get_all('formas_pagamentos'),
            );

            // echo '<pre>';
            // print_r($data['formas_pagamentos']);
            // exit();

            $this->load->view('layout/header', $data);
            $this->load->view('formas_pagamentos/index');
            $this->load->view('layout/footer');
        }

        public function add($forma_pagamento_id = NULL){

                $this->form_validation->set_rules('forma_pagamento_nome', '', 'trim|required|min_length[1]|max_length[45]|callback_check_pagamento_nome');
		        $this->form_validation->set_rules('forma_pagamento_aceita_parc', '', 'trim|required');
		        $this->form_validation->set_rules('forma_pagamento_ativa', '', 'trim|max_length[250]');

                if($this->form_validation->run()){
                    $data = elements(
                        array(
                            'forma_pagamento_nome',
                            'forma_pagamento_aceita_parc',
                            'forma_pagamento_ativa',
                        ),$this->input->post(),
                    );
                    
                    $data = html_escape($data);
                    $this->core_model->insert('formas_pagamentos', $data);
                    redirect('formas_pagamentos');
                }else{
                    $data = array(
                        'titulo' => 'Cadastro de forma de pagamento',
                    );

                $this->load->view('layout/header', $data);
                $this->load->view('formas_pagamentos/add');
                $this->load->view('layout/footer');
                }

                // echo '<pre>';
                // print_r($data['formas_pagamentos']);
                // exit();

                
        }

        public function edit($forma_pagamento_id = NULL){
            if(!$forma_pagamento_id || !$this->core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id))){
                $this->session->set_flashdata('error', 'Forma de Pagamento não encontrada');
                redirect('formas_pagamentos');
            }else{
                
                $this->form_validation->set_rules('forma_pagamento_nome', '', 'trim|required|min_length[1]|max_length[45]|callback_check_pagamento_nome');
		        $this->form_validation->set_rules('forma_pagamento_aceita_parc', '', 'trim|required');
		        $this->form_validation->set_rules('forma_pagamento_ativa', '', 'trim|max_length[250]');

                if($this->form_validation->run()){
                    $forma_pagamento_ativa = $this->input->post('forma_pagamento_ativa');

                    //Para vendas
                    if($this->db->table_exists('ordem_servicos')){
                        if($forma_pagamento_ativa = 2 && $this->core_model->get_by_id('ordem_servico', array('ordem_servico_forma_pagamento_id' => $forma_pagamento_id))){
                            $this->session->set_flasdata('error', 'Essa forma de pabamento não pode ser desativada, pois está sendo utilizada em Ordem de Serviços');
                            redirect('pagamentos');
                        }
                    }

                    $data = elements(
                        array(
                            'forma_pagamento_nome',
                            'forma_pagamento_aceita_parc',
                            'forma_pagamento_ativa',
                        ),$this->input->post(),
                    );

                    $data = html_escape($data);
                    $this->core_model->update('formas_pagamentos', $data, array('forma_pagamento_id' => $forma_pagamento_id));
                    redirect('formas_pagamentos');
                }else{
                    $data = array(
                        'titulo' => 'Editando forma de pagamento',
                        'formas_pagamentos' => $this->core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id)),
                    );

                    // echo '<pre>';
                    // print_r($data['formas_pagamentos']);
                    // exit();

                    $this->load->view('layout/header', $data);
                    $this->load->view('formas_pagamentos/edit');
                    $this->load->view('layout/footer');
                }
            }
        }

        public function del($forma_pagamento_id = NULL){
            //verifica no banco se existe algum cliente //
            if(!$forma_pagamento_id || !$this->core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id))){
                $this->session->set_flashdata('error','Forma de pagameto não encontrada!');
                redirect('modulo/financeiro');
            }

                //verifica no banco se existe algum cliente //
            if($this->core_model->get_by_id('formas_pagamentos', array('forma_pagamento_id' => $forma_pagamento_id, 'forma_pagamento_ativa' => 1))){
                $this->session->set_flashdata('info','Atenção: Não e possível excluir uma forma de pagamentos,  que está ativa!');
                redirect('modulo/financeiro');
            }

            $this->core_model->delete('formas_pagamentos',  array('forma_pagamento_id' => $forma_pagamento_id));
            redirect('modulo/financeiro');
        }
        
        public function check_pagamento_nome($forma_pagamento_nome){

            $forma_pagamento_id = $this->input->post('forma_pagamento_id');
        
            if($this->core_model->get_by_id('formas_pagamentos', array('forma_pagamento_nome' => $forma_pagamento_nome, 'forma_pagamento_id !=' => $forma_pagamento_id))){
                $this->form_validation->set_message('check_pagamento_nome','Essa forma de pagamentos já existe!');
                //$this->Form_validation->set_message('check_pagamento_nome','Essa forma de pagamentos já existe!');
                return false;
            }else{
                return true;
        
            }
        }
    }
?>