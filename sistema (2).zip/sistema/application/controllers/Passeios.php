<?php
    defined('BASEPATH') OR exit ('Ação não permitida');

    class Passeios extends CI_Controller{

        public function __construct(){
            parent::__construct();

            if(!$this->ion_auth->logged_in()){
                $this->session->set_flashdata('info', 'Sua sessão expirou');
                redirect('login');
            }
        }

        
        public function index(){
            $data = array(
                'titulo' => 'Passeios Cadastrados',

                'styles' => array(
                    'vendor/datatables/dataTables.bootstrap4.min.css',
                ),
                'scripts' => array(
                    'vendor/datatables/jquery.dataTables.min.js',
                    'vendor/datatables/dataTables.bootstrap4.min.js',
                    'vendor/datatables/app.js'
                ),
                'passeios' => $this->core_model->get_all('passeios'),
            );

            $this->load->view('layout/header', $data);
            $this->load->view('passeios/index');
            $this->load->view('layout/footer');
        }

        public function add() {

            $this->form_validation->set_rules('passeio_nome', '', 'trim|required|min_length[10]|max_length[145]|is_unique[passeios.passeio_nome]');
            $this->form_validation->set_rules('passeio_preco', '', 'trim|required');
            $this->form_validation->set_rules('passeio_descricao', '', 'trim|required|max_length[700]');
    
    
            if ($this->form_validation->run()) {
    
    
                $data = elements(
                        array(
                    'passeio_nome',
                    'passeio_descricao',
                    'passeio_preco',
                    'passeio_trajeto',
                    'passeio_ocupantes',
                    'passeio_status',                 
                    
                        ), $this->input->post()
                );
    
                $data = html_escape($data);
                
                $this->core_model->insert('passeios', $data);
    
                redirect('passeios');
            } else {    
    
                //Erro de validação
    
                $data = array(
                    'titulo' => 'Cadastrar Passeio',
                    'scripts' => array(
                        'vendor/mask/jquery.mask.min.js',
                        'vendor/mask/app.js',
                    ),
                );
    
                $this->load->view('layout/header', $data);
                $this->load->view('passeios/add');
                $this->load->view('layout/footer');
            }
        }
    }