<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
    
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('/')?>">
        <i class="fas fa-home"></i>
        <span>Home</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Módulos
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOne"
        aria-expanded="true" aria-controls="collapseFive">
        <i class="fas fa-shopping-cart"></i>
        <span>Vendas</span>
    </a>
    <div id="collapseOne" class="collapse" aria-labelledby="collapseFive" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção</h6>
            <a class="collapse-item" href="<?=base_url('modulo/financeiro/vendas/os');?>"><i class="fas fa-shopping-basket text-gray-900"></i>&nbsp;&nbsp;Ordem Serviços</a>
            <a class="collapse-item" href="<?=base_url('modulo/financeiro/vendas/vender');?>"><i class="fas fa-cash-register text-gray-900"></i>&nbsp;&nbsp;PDV</a>
        </div>
    </div>
</li>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
        aria-expanded="true" aria-controls="collapseOne">
        <i class="fas fa-database"></i>
        <span>Cadastros</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTree" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção</h6>
            <a class="collapse-item" href="<?=base_url('clientes');?>"><i class="fas fa-user-tie text-gray-900"></i>&nbsp;&nbsp;Clientes</a>
            <a class="collapse-item" href="<?=base_url('fornecedores');?>"><i class="fas fa-user-tag text-gray-900"></i>&nbsp;&nbsp;Fornecedores</a>
            <a class="collapse-item" href="<?=base_url('vendedores');?>"><i class="fas fa-user-secret text-gray-900"></i>&nbsp;&nbsp;Vendedores</a>
            <a class="collapse-item" href="<?=base_url('servicos');?>"><i class="fas fa-hammer text-gray-900"></i>&nbsp;&nbsp;Serviços</a>
        </div>
    </div>
</li>

<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTree"
        aria-expanded="true" aria-controls="collapseTree">
        <i class="fas fa-dolly-flatbed"></i>
        <span>Estoque</span>
    </a>
    <div id="collapseTree" class="collapse" aria-labelledby="headingTree" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção</h6>
            <a class="collapse-item" href="<?=base_url('marcas');?>"><i class="fas fa-bullhorn text-gray-900"></i>&nbsp;&nbsp;Marcas</a>
            <a class="collapse-item" href="<?=base_url('produtos');?>"><i class="fas fa-barcode text-gray-900"></i>&nbsp;&nbsp;Produtos</a>
            <a class="collapse-item" href="<?=base_url('categorias');?>"><i class="fab fa-buffer text-gray-900"></i>&nbsp;&nbsp;Categorias</a>
        </div>
    </div>
</li>

<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
        aria-expanded="true" taria-controls="collapseFour">
        <i class="fas fa-wallet"></i>
        <span>Financeiro</span>
    </a>
    <div id="collapseFour" class="collapse" aria-labelledby="headingSix" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção</h6>
            <a class="collapse-item" href="<?=base_url('pagar');?>"><i class="far fa-money-bill-alt text-gray-900"></i>&nbsp;&nbsp;Contas a Pagar</a>
            <a class="collapse-item" href="<?=base_url('receber');?>"><i class="fas fa-hand-holding-usd text-gray-900"></i>&nbsp;&nbsp;Contas a Receber</a>
            <a class="collapse-item" href="<?=base_url('modulo/financeiro');?>"><i class="fas fa-money-check-alt text-gray-900"></i>&nbsp;&nbsp;Formas de Pagamento</a>
        </div>
    </div>
</li>

<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
        aria-expanded="true" aria-controls="collapseTwo">
        <i class="fa-solid fa-motorcycle"></i>
        <span>Passeios</span>
    </a>
    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Escolha uma opção</h6>
            <a class="collapse-item" href="<?=base_url('passeios/agenda');?>"><i class="fa-solid fa-calendar-days text-gray-900"></i>&nbsp;&nbsp;Abrir Agenda</a>
            <a class="collapse-item" href="<?=base_url('passeios');?>"><i class="fa-regular fa-rectangle-list text-gray-900"></i>&nbsp;&nbsp;Catálogo passeio</a>
            <a class="collapse-item" href="<?=base_url('passeios/horario_embarque');?>"><i class="fa-solid fa-person-chalkboard text-gray-900"></i>&nbsp;&nbsp;Horário embarque</a>
        </div>
    </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Configurações
</div>

<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('usuarios');?>" title="Gerenciar dados do usuário">
        <i class="fa-solid fa-users"></i>
        <span>Usuários</span></a>
</li>

<!-- Nav Item - Tables -->
<li class="nav-item">
    <a class="nav-link" href="<?=base_url('sistema');?>" title="Gerenciar dados do sistema">
        <i class="fa-solid fa-gears"></i>
        <span>Sistema</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">