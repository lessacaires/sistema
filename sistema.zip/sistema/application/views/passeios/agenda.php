<?php $this->load->view('layout/sidebar'); ?>


<!-- Main Content -->
<div id="content">

    <?php $this->load->view('layout/navbar'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<div class="alert alert-warning" role="alert">
Essa página ainda está em desenvolvimento
</div>
<a title="Voltar" href="<?php echo base_url('/'); ?>" class="btn btn-secondary btn-sm ml-2">Voltar</a>
<br/>
<br/>
<br/>
<br/>

<div class="col-cm-6">
<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="dados-tab" data-bs-toggle="tab" data-bs-target="#dados-tab-pane" type="button" role="tab" aria-controls="dados-tab-pane" aria-selected="true">Dados</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="horario-tab" data-bs-toggle="tab" data-bs-target="#horario-tab-pane" type="button" role="tab" aria-controls="horario-tab-pane" aria-selected="false">Horário e frequência</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#itens-tab-pane" type="button" role="tab" aria-controls="itens-tab-pane" aria-selected="false">Itens do passeio e valores</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#locais-tab-pane" type="button" role="tab" aria-controls="locais-tab-pane" aria-selected="false">Locais de embarque</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#faixa-tab-pane" type="button" role="tab" aria-controls="faixa-tab-pane" aria-selected="false">Faixa etária</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#info-tab-pane" type="button" role="tab" aria-controls="info-tab-pane" aria-selected="false">infromações voucher</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#site-tab-pane" type="button" role="tab" aria-controls="site-tab-pane" aria-selected="false">Site</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#endereco-tab-pane" type="button" role="tab" aria-controls="endereco-tab-pane" aria-selected="false">Endereço</button>
  </li>
</ul>
<br/>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="dados-tab-pane" role="tabpanel" aria-labelledby="dados-tab" tabindex="0">1</div>
  <div class="tab-pane fade" id="horario-tab-pane" role="tabpanel" aria-labelledby="horario-tab" tabindex="0">2</div>
  <div class="tab-pane fade" id="itens-tab-pane" role="tabpanel" aria-labelledby="itens-tab" tabindex="0">3</div>
  <div class="tab-pane fade" id="locais-tab-pane" role="tabpanel" aria-labelledby="locais-tab" tabindex="0">4</div>
  <div class="tab-pane fade" id="faixa-tab-pane" role="tabpanel" aria-labelledby="faixa-tab" tabindex="0">5</div>
  <div class="tab-pane fade" id="info-tab-pane" role="tabpanel" aria-labelledby="info-tab" tabindex="0">6</div>
  <div class="tab-pane fade" id="site-tab-pane" role="tabpanel" aria-labelledby="site-tab" tabindex="0">7</div>
  <div class="tab-pane fade" id="endereco-tab-pane" role="tabpanel" aria-labelledby="endereco-tab" tabindex="0">8</div>
</div>
</div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->