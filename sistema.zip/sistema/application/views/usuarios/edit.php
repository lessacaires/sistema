<?php $this->load->view('layout/sidebar'); ?>

<?php $this->load->view('layout/navbar'); ?>

            <!-- Main Content -->
            <div id="content">

                    <!-- Begin Page Content -->
                    <div class="container-fluid">

                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo base_url('usuarios'); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
                        </ol>
                    </nav>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                        <h4 class="titulo">Editando os dados do usuário: <?=$usuarios->username;?></h4>
                            <a title="Voltar" href="<?php echo base_url('usuarios'); ?>" class="btn btn-success btn-sm float-right mb-0"><i class="fas fa-arrow-left"></i>&nbspVoltar</a>
                        </div>
                        <div class="card-body">
                            <form method="post" name="form_edit">
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <label for="inputNome">Nome</label>
                                        <input type="text" class="form-control" placeholder="Nome" name="first_name" value="<?= $usuarios->first_name ?>">
                                        <?php echo form_error('first_name', '<smal class="form-text text-danger">','</smal>');?>
                                    </div>
                                <div class="form-group col-md-4">
                                    <label for="inputSobrenome">Sobrenome</label>
                                    <input type="text" class="form-control" placeholder="Sobrenome" name="last_name" value="<?= $usuarios->last_name ?>">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="inputEmail4">Email</label>
                                    <input type="email" class="form-control" id="inputEmail4" placeholder="Email" name="email" value="<?= $usuarios->email ?>">
                                </div>
                                </div>
                                <div class="form-group row">
                            <div class="col-md-4">
                                <label for="inputAddress">Usuário</label>
                                <input type="text" class="form-control" placeholder="Username" name="username" value="<?= $usuarios->username ?>">
                            </div>
                                <div class="col-md-4">
                                <label for="inputAddress">Perfil de Acesso</label>
                                    <select class="form-control" name="perfil_usuario">
                                        <option value="2"<?php echo $perfil_usuario->id == 2 ? 'selected' : ''; ?>>Vendedor</option>
                                        <option value="1"<?php echo $perfil_usuario->id == 1 ? 'selected' : ''; ?>>Administrador</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                <label for="inputAddress">Usuário Ativo</label>
                                    <select class="form-control" name="active">
                                        <option value="2"<?php echo $usuarios->active == 2 ? 'selected' : ''; ?>>Não</option>
                                        <option value="1"<?php echo $usuarios->active == 1 ? 'selected' : ''; ?>>Sim</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="inputEmail4">Senha</label>
                                    <input type="password" class="form-control" name="password" placeholder="Senha">
                                </div>
                                <div class="col-md-6">
                                    <label for="inputEmail4">Confirmação de senha</label>
                                    <input type="password" class="form-control" name="confirmpassword" placeholder="Senha" >
                                </div>
                                <input type="hidden" name="usuario_id" value="<?=$usuarios->id;?>">
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm">Atualizar <i class="fas fa-rotate"></i></button>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->