<?php $this->load->view('layout/sidebar'); ?>
<?php $this->load->view('layout/navbar'); ?>
<!-- Main Content -->
<div id="content">
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('clientes'); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
            </ol>
        </nav>
        <div class="card shadow mb-4">
            <div class="card-header py-3 pb-4">
                <h4 class="titulo mb-1"><?=$titulo?></h4>
            </div>
            <div class="card-body">
                    <form method="post" name="form_edit">
                        <fildset class="form-group mb-2">
                            <legend><i class="fas fa-user-tie "></i>&nbsp;&nbsp;Dados Pessoais</legend>
                            <div class="form-row">
                                <div class="col-md-5">
                                    <label for="inputNome">Nome</label>
                                    <input type="text" class="form-control" placeholder="Nome do cliente" name="cliente_first_name" value="<?=$cliente->cliente_nome?>">
                                    <?php echo form_error('first_name', '<smal class="form-text text-danger">','</smal>');?>
                                </div>
                                <div class="col-md-5">
                                    <label for="inputSobrenome">Sobrenome</label>
                                    <input type="text" class="form-control" placeholder="Sobrenome do cliente" name="cliente_last_name" value="<?=$cliente->cliente_sobrenome?>">
                                    <?php echo form_error('last_name', '<smal class="form-text text-danger">','</smal>');?>
                                </div>
                                <div class="col-md-2">
                                    <label for="inputAddress">Data Nascimento</label>
                                    <input type="date" class="form-control" placeholder="Data de Nasc name=" cliente_data_nascimento" value="<?=$cliente->cliente_data_nascimento?>">
                                    <?php echo form_error('cliente_cep', '<smal class="form-text text-danger">','</smal>');?>
                                </div>
                            </div>
                        <div class="form-row">
                            <div class="col-md-2">
                                <label for="inputAddress">CPF / CNPJ</label>
                                <input type="text" class="form-control cnpj" placeholder="CPF ou CNPJ" name="username" value="">
                                <?php echo form_error('cliente_cpf_cnpj', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="col-md-2">
                                <label for="inputAddress">RG / I.E</label>
                                <input type="text" class="form-control " placeholder="CPF ou CNPJ" name="username" value="<?=$cliente->cliente_rg_ie?>">
                                <?php echo form_error('cliente_rg_ie', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <input type="hidden" name="usuario_id" value=<?=$cliente->cliente_id?>>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="inputEmail">Email</label>
                                <input type="text" class="form-control" placeholder="Email do cliente" name="cliente_email" value="<?=$cliente->cliente_email?>">
                                <?php echo form_error('cliente_email', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="form-group col-md-2">
                                <label for="inputSobrenome">Telefone Fixo</label>
                                <input type="text" class="form-control phones" placeholder="Telefone do cliente" name="cliente_telefone" value="<?=$cliente->cliente_telefone?>">
                                <?php echo form_error('cliente_telefone', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="col-md-2">
                                <label for="inputAddress">Telefone Celular</label>
                                <input type="text" class="form-control phones" placeholder="Telefone celular do cliente" name="cliente_celular" value="<?=$cliente->cliente_celular?>">
                                <?php echo form_error('cliente_celular', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                        </fildset>
                            <input type="hidden" name="usuario_id" value=<?=$cliente->cliente_id?>>
                        </div>
                        <fildset class="form-group mb-2">
                        <legend><i class="fas fa-map-marker-alt "></i>&nbsp;&nbsp;Dados de Endereço</legend>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <label for="inputEmail">CEP</label>
                                <input type="text" class="form-control" placeholder="Email do cliente" name="cliente_email" value="<?=$cliente->cliente_email?>">
                                <?php echo form_error('cliente_email', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="inputSobrenome">Endereço</label>
                                <input type="text" class="form-control phones" placeholder="Telefone do cliente" name="cliente_telefone" value="<?=$cliente->cliente_telefone?>">
                                <?php echo form_error('cliente_telefone', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="col-md-1">
                                <label for="inputAddress">Número</label>
                                <input type="text" class="form-control phones" placeholder="Telefone celular do cliente" name="cliente_celular" value="<?=$cliente->cliente_celular?>">
                                <?php echo form_error('cliente_celular', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="col-md-4">
                                <label for="inputAddress">Bairro</label>
                                <input type="text" class="form-control" placeholder="Data de Nasc name=" cliente_data_nascimento" value="<?=$cliente->cliente_data_nascimento?>">
                                <?php echo form_error('cliente_cep', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-5">
                                <label for="inputEmail">Cidade</label>
                                <input type="text" class="form-control" placeholder="Cidade do cliente" name="cliente_cidade" value="<?=$cliente->cliente_cidade?>">
                                <?php echo form_error('cliente_email', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="form-group col-md-1">
                                <label for="inputSobrenome">UF</label>
                                <input type="text" class="form-control phones" placeholder="UF do Cliente" name="cliente_estado" value="<?=$cliente->cliente_estado?>">
                                <?php echo form_error('cliente_estado', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <div class="col-md-6">
                                <label for="inputAddress">Observações</label>
                                <input type="text" class="form-control phones" placeholder="Observações sobre o cliente" name="cliente_obs" value="<?=$cliente->cliente_obs?>">
                                <?php echo form_error('cliente_obs', '<smal class="form-text text-danger">','</smal>');?>
                            </div>
                            <input type="hidden" name="usuario_id" value=<?=$cliente->cliente_id?>>
                        </div>
                    </fildset>
                        <a title="Voltar" href="<?php echo base_url('clientes'); ?>" class="btn btn-success btn-sm mb-0"><i class="fas fa-arrow-left"></i>&nbspVoltar</a>
                        <button type="submit" class="btn btn-primary btn-sm">Atualizar <i class="fas fa-rotate"></i></button>
                    </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- End of Main Content -->