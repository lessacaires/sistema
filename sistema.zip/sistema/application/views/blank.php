<?php $this->load->view('layout/sidebar'); ?>


<!-- Main Content -->
<div id="content">

    <?php $this->load->view('layout/navbar'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<div class="alert alert-warning" role="alert">
Essa página ainda está em desenvolvimento
</div>
<a title="Voltar" href="<?php echo base_url('/'); ?>" class="btn btn-secondary btn-sm ml-2">Voltar</a>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->