<?php $this->load->view('layout/sidebar'); ?>

<?php $this->load->view('layout/navbar'); ?>

            <!-- Main Content -->
            <div id="content">

                    <!-- Begin Page Content -->
                    <div class="container-fluid">

                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo base_url('sistema'); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
                        </ol>
                    </nav>
                    <?php if ($message = $this->session->flashdata('sucesso')): ?>
                        <div class="row">
                            <div class="col-md-12">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong><i class="fa-solid fa-check"></i>&nbsp&nbsp<?= $message ?></strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($message = $this->session->flashdata('error')): ?>
                        <div class="row">
                            <div class="col-md-12">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><i class="fas fa-exclamation-triangle"></i>&nbsp&nbsp<?= $message ?></strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h4 class="titulo">Editando os dados do sistema:</h4>
                            <a title="Voltar" href="<?php echo base_url('sistema'); ?>" class="btn btn-success btn-sm float-right mb-0"><i class="fas fa-arrow-left"></i>&nbspVoltar</a>
                        </div>
                        <div class="card-body">
                            <form method="post" name="form_edit">
                                <div class="form-row">
                                    <div class="form-group col-md-3">
                                        <label for="inputNome">Razão Social</label>
                                        <input type="text" class="form-control" placeholder="Digite a razão Social" name="sistema_razao_social" value="<?= $sistema->sistema_razao_social ?>">
                                        <?php echo form_error('sistema_razao_social', '<smal class="form-text text-danger">', '</smal>'); ?>
                                    </div>
                                <div class="form-group col-md-3">
                                    <label for="inputSobrenome">Nome Fantasia</label>
                                    <input type="text" class="form-control" placeholder="Digite o Nome Fantasia" name="sistema_nome_fantasia" value="<?= $sistema->sistema_nome_fantasia ?>">
                                    <?php echo form_error('sistema_nome_fantasia', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="inputEmail4">CNPJ</label>
                                    <input type="text" class="form-control" placeholder="Digite o CNPJ" name="sistema_cnpj" value="<?= $sistema->sistema_cnpj ?>">
                                    <?php echo form_error('sistema_cnpj', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="inputEmail4">IE</label>
                                    <input type="text" class="form-control" placeholder="Digite a Inscrição Estadual" name="sistema_ie" value="<?= $sistema->sistema_ie ?>">
                                    <?php echo form_error('sistema_ie', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>  
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-5">
                                    <label for="inputNome">Endereço</label>
                                    <input type="text" class="form-control" placeholder="Digite a razão Social" name="sistema_endereco" value="<?= $sistema->sistema_endereco ?>">
                                    <?php echo form_error('sistema_endereco', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-1">
                                    <label for="inputNome">Número</label>
                                    <input type="text" class="form-control" placeholder="Digite a razão Social" name="sistema_numero" value="<?= $sistema->sistema_numero ?>">
                                    <?php echo form_error('sistema_numero', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="inputSobrenome">Cidade</label>
                                    <input type="text" class="form-control" placeholder="Digite o Nome Fantasia" name="sistema_cidade" max_length="2" value="<?= $sistema->sistema_cidade ?>">
                                    <?php echo form_error('sistema_cidade', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-1">
                                    <label for="inputEmail4">Estado</label>
                                    <input type="text" class="form-control" placeholder="Digite o CNPJ" name="sistema_estado" value="<?= $sistema->sistema_estado ?>">
                                    <?php echo form_error('sistema_estado', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="inputEmail4">CEP</label>
                                    <input type="text" class="form-control" placeholder="Digite o CEP" name="sistema_cep" value="<?= $sistema->sistema_cep ?>">
                                    <?php echo form_error('sistema_cep', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>  
                            </div>
                            <div class="form-row">
                                    <div class="form-group col-md-3">
                                        <label for="inputNome">Telefone Fixo</label>
                                        <input type="text" class="form-control" placeholder="Digite o seu telefone" name="sistema_telefone_fixo " value="<?= $sistema->sistema_telefone_fixo ?>">
                                        <?php echo form_error('sistema_telefone_fixo ', '<smal class="form-text text-danger">', '</smal>'); ?>
                                    </div>
                                <div class="form-group col-md-3">
                                    <label for="inputSobrenome">Telefone Celular</label>
                                    <input type="text" class="form-control" placeholder="Digite o seu celular" name="sistema_telefone_movel" value="<?= $sistema->sistema_telefone_movel ?>">
                                    <?php echo form_error('sistema_telefone_movel', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="inputEmail4">Site</label>
                                    <input type="text" class="form-control" placeholder="Digite a urh do site" name="sistema_site_url" value="<?= $sistema->sistema_site_url ?>">
                                    <?php echo form_error('sistema_site_url', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="inputEmail4">Email</label>
                                    <input type="email" class="form-control" placeholder="Digite o seu email" name="sistema_email" value="<?= $sistema->sistema_email ?>">
                                    <?php echo form_error('sistema_email', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="inputEmail4">Texto da Ordem de Serviço e Venda</label>
                                    <textarea class="form-control"  rows="3" placeholder="Texto da Ordem de Serviço e Venda" name="sistema_txt_ordem_servico"></textarea>  
                                    <?php echo form_error('sistema_txt_ordem_servico', '<smal class="form-text text-danger">', '</smal>'); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm">Salvar <i class="fas fa-plus"></i></button>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->