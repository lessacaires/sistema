<?php
    defined('BASEPATH')OR exit('Ação não permitida');

    class Ordem_servicos extends CI_Controller{
        public function __Construct(){
            parent::__Construct();

            if(!$this->ion_auth->logged_in()){
                $this->session->set_flashdata('info', 'Sua sessão expirou');
                redirect('login');
            }
            $this->load->model('ordem_servicos_model');
        }

        public function index(){
            $data =  array(
    
                'titulo' => 'Listagem de Ordem de Serviços',
    
                'styles' => array(
                    
                    'vendor/datatables/dataTables.bootstrap4.min.css',
    
                ),
    
                'scripts' => array(
                    
                    'vendor/datatables/jquery.dataTables.min.js',
                    'vendor/datatables/app.js',
                    'js/app.js',
                    'js/jquery.mask.min.js',
                    'vendor/datatables/dataTables.bootstrap4.min.js',
                    'js/demo/datatables-demo.js'
                ),
                'ordens_servicos' => $this->ordem_servicos_model->get_all(),
            );
                 //erro na validação 
                /*echo'<pre>';
                print_r($data['ordens_servicos']);
                exit();*/
                $this->load->view('layout/header', $data);
                $this->load->view('ordem_servicos/index');
                $this->load->view('layout/footer');
    
            }

        public function edit($ordem_servico_id){
            if(!$ordem_servico_id || !$this->core_model->get_by_id('ordens_servicos', array('ordem_servico_id' => $ordem_servico_id))){
                $this->session->set_flashdata('error', 'Ordem de serviço não encontrada');
                redirect('modulo/vendas/os');
            }else{
                
                $this->form_validation->set_rules('ordem_servico_cliente_id', '', 'required');

				$ordem_servico_status = $this->input->post('ordem_servico_status');

				if($ordem_servico_status == 1){
					$this->form_validation->set_rules('ordem_servico_forma_pagamento_id', '', 'trim|required');

				}				

				$this->form_validation->set_rules('ordem_servico_equipamento', 'Marca', 'trim|required|min_length[1]|max_length[80]');
				$this->form_validation->set_rules('ordem_servico_marca_equipamento', 'Marca', 'trim|required|min_length[1]|max_length[80]');
				$this->form_validation->set_rules('ordem_servico_modelo_equipamento', 'Modelo', 'trim|required|min_length[1]|max_length[80]');
				$this->form_validation->set_rules('ordem_servico_acessorios', 'Acessórios', 'trim|required|min_length[1]|max_length[380]');
				$this->form_validation->set_rules('ordem_servico_defeito', 'Defeito', 'trim|required|min_length[1]|max_length[780]');

                if($this->form_validation->run()){

                    $data = elements(
                        array(
                            'ordem_servico_cliente_id',
                            'ordem_servico_forma_pagamento_id',
                            'ordem_servico_status',
                            'ordem_servico_equipamento',
                            'ordem_servico_marca_equipamento',
                            'ordem_servico_modelo_equipamento',
                            'ordem_servico_defeito',
                            'ordem_servico_acessorios',
                            'ordem_servico_obs',
                            'ordem_servico_valor_desconto',
                            'ordem_servico_valor_total'
                        ),$this->input->post()
                    );

                    echo '<pre>';
                    print_r($data);
                    exit();

                }else{
                    $data =  array(

						'titulo' => 'Edição de Ordem de Serviços',
						'styles' => array(
							'vendor/select2/select2.min.css',
							'vendor/autocomplete/jquery-ui.css',
							'vendor/autocomplete/estilo.css',

						),

						'scripts' => array(
							'vendor/autocomplete/jquery-migrate.js',
							'vendor/calcx/jquery-calx-sample-2.2.8.min.js',
							'vendor/calcx/os.js',
							'vendor/select2/select2.min.js',
							'vendor/select2/app.js',
							'vendor/sweetalert2/app.js',
							'vendor/autocomplete/jquery-ui.js',
						),

						'clientes' => $this->core_model->get_all('clientes', array('cliente_ativo' => 1)),
						'formas_pagamentos' => $this->core_model->get_all('formas_pagamentos', array('forma_pagamento_ativa' => 1)),
						//'os_tem_servicos' => $this->ordem_servicos_model->get_all_servicos_by_ordem($ordem_servico_id),

					);
                }
            }
        }
    }
?>