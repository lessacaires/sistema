<?php
    defined('BASEPATH') OR exit('Ação não permitida');

    class Produtos extends CI_Controller{
        
        public function __Construct(){
            parent::__Construct();
            if(!$this->ion_auth->logged_in()){
                $this->session->set_flashdata('error', 'Sua sessão expirou');
                redirect('login');
            }

            $this->load->model('produtos_model');
        }
        
        public function index() {

            $data = array(
                'titulo' => 'Produtos cadastrados',
                'styles' => array(
                    'vendor/datatables/dataTables.bootstrap4.min.css',
                ),
                'scripts' => array(
                    'vendor/datatables/jquery.dataTables.min.js',
                    'vendor/datatables/dataTables.bootstrap4.min.js',
                    'vendor/datatables/export/dataTables.buttons.min.js',
                    'vendor/datatables/export/pdfmake.min.js',
                    'vendor/datatables/export/vfs_fonts.js',
                    'vendor/datatables/export/buttons.html5.min.js',
                    'vendor/datatables/app.js'
                ),
                'produtos' => $this->produtos_model->get_all(),
            );
    
        //    echo '<pre>';
        //    print_r($data);
        //    exit();
    
    
            $this->load->view('layout/header', $data);
            $this->load->view('produtos/index');
            $this->load->view('layout/footer');
        }
    }
?>