<?php
    defined('BASEPATH') OR exit('Ação não Permitida');

    class Clientes extends CI_Controller{
        public function __Construct(){
            parent::__Construct();

        }

        public function index(){

            $data = array(
                'titulo' => 'Clientes Cadastrados',

                'styles' => array(
                    'vendor/datatables/dataTables.bootstrap4.min.css',
                ),
                'scripts' => array(
                    'vendor/datatables/jquery.dataTables.min.js',
                    'vendor/datatables/dataTables.bootstrap4.min.js',
                    'vendor/datatables/app.js'
                ),
                'clientes' => $this->core_model->get_all('clientes'),
            );

            // echo '<pre>';
            // print_r($data);
            // exit();

            $this->load->view('layout/header', $data);
            $this->load->view('clientes/index');
            $this->load->view('layout/footer');
        }
    }
?>