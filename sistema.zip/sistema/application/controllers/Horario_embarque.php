<?php

    defined('BASEPATH') OR exit ('Ação não permitida');

    class Horario_embarque extends CI_Controller{
        public function __construct(){
            parent::__construct();

            if(!$this->ion_auth->logged_in()){
                $this->session->set_flasdata('info', 'Sua sessão expirou');
                redirect('login');
            }
        }

        public function index(){

            $data = array(
                'titulo' => 'Programar horário de embarque dos Passeios nos locais e regiões',
                'styles' => array(
                    'vendor/datatables/dataTables.bootstrap4.min.css',
                ),
                'scripts' => array(
				
                    'vendor/datatables/jquery.dataTables.min.js',
                    'vendor/datatables/app.js',
                    'js/app.js',
                    'js/jquery.mask.min.js',
                    'vendor/datatables/dataTables.bootstrap4.min.js',
                    'js/demo/datatables-demo.js'
                ),
                //'formas_pagamentos' => $this->core_model->get_all('horario_embarque'),
            );

            // echo '<pre>';
            // print_r($data['embarque']);
            // exit();

            $this->load->view('layout/header', $data);
            $this->load->view('passeios/horario_embarque');
            $this->load->view('layout/footer');
        }
    }